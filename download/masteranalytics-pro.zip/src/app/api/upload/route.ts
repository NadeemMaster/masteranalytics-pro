// ============================================================================
//  MasterAnalytics Pro — /api/upload Route Handler
//  Receives .xlsx file, parses it, and upserts rows into Supabase.
//
//  CRITICAL LOGIC:
//   - Day 1, 2, 3 → daily_campaign_data (upsert on user_id+campaign+tehsil+uc)
//     Because Days 1-3 are CUMULATIVE, the latest upload REPLACES the previous
//     day's row for the same UC. The unique constraint does NOT include
//     campaign_day, so the upsert overwrites all columns including campaign_day.
//   - Day 4 → catchup_campaign_data (same upsert pattern)
//
//  RLS: uses the authenticated server client. user_id comes from the session,
//       NEVER from the request body — RLS auto-fills it.
//
//  Author: M. Nadeem Akhtar (https://www.facebook.com/itxmasterjee)
// ============================================================================

import { NextResponse, type NextRequest } from "next/server";

import { createClient, getUser } from "@/lib/supabase/server";
import { parseExcelFile } from "@/lib/excel/parser";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// 10 MB file size limit (matches next.config.mjs bodySizeLimit)
const MAX_FILE_BYTES = 10 * 1024 * 1024;

const ACCEPTED_EXTENSIONS = [".xlsx", ".xls"];
const ACCEPTED_MIME_TYPES = [
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-excel",
  "application/octet-stream", // some browsers send this for .xlsx
];

export async function POST(request: NextRequest) {
  // ---- 1. Authenticate ----
  const user = await getUser();
  if (!user) {
    return NextResponse.json(
      { error: "Unauthorized. Please sign in." },
      { status: 401 }
    );
  }

  // ---- 2. Parse multipart form data ----
  let formData: FormData;
  try {
    formData = await request.formData();
  } catch {
    return NextResponse.json(
      { error: "Invalid request. Expected multipart/form-data." },
      { status: 400 }
    );
  }

  const file = formData.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json(
      { error: "No file uploaded. Use field name 'file'." },
      { status: 400 }
    );
  }

  // ---- 3. Validate file ----
  const fileName = file.name;
  const fileExt = fileName.slice(fileName.lastIndexOf(".")).toLowerCase();

  if (!ACCEPTED_EXTENSIONS.includes(fileExt)) {
    return NextResponse.json(
      {
        error: `Unsupported file type '${fileExt}'. Accepted: ${ACCEPTED_EXTENSIONS.join(", ")}`,
      },
      { status: 400 }
    );
  }

  if (
    file.type &&
    ACCEPTED_MIME_TYPES.length > 0 &&
    !ACCEPTED_MIME_TYPES.includes(file.type)
  ) {
    // Don't hard-fail on MIME type — browsers are inconsistent. Just warn.
    console.warn(`[upload] Unexpected MIME type '${file.type}' for ${fileName}`);
  }

  if (file.size === 0) {
    return NextResponse.json(
      { error: "File is empty." },
      { status: 400 }
    );
  }

  if (file.size > MAX_FILE_BYTES) {
    return NextResponse.json(
      {
        error: `File too large (${(file.size / 1024 / 1024).toFixed(2)} MB). Max ${MAX_FILE_BYTES / 1024 / 1024} MB.`,
      },
      { status: 413 }
    );
  }

  // ---- 4. Read file buffer ----
  let fileBuffer: ArrayBuffer;
  try {
    fileBuffer = await file.arrayBuffer();
  } catch {
    return NextResponse.json(
      { error: "Failed to read file buffer." },
      { status: 500 }
    );
  }

  // ---- 5. Parse Excel ----
  let summary;
  try {
    summary = parseExcelFile(fileBuffer, fileName);
  } catch (err) {
    console.error("[upload] Excel parse failed:", err);
    return NextResponse.json(
      {
        error: "Failed to parse Excel file.",
        detail: err instanceof Error ? err.message : "Unknown parse error",
      },
      { status: 422 }
    );
  }

  if (summary.totalRows === 0) {
    return NextResponse.json(
      {
        error: "File contains no data rows.",
        fileName,
        sheetName: summary.sheetName,
      },
      { status: 422 }
    );
  }

  // ---- 6. Upsert to Supabase ----
  const supabase = await createClient();

  const upsertConflict = "user_id,campaign_name,tehsil,uc_name";

  type UpsertResult = {
    table: "daily_campaign_data" | "catchup_campaign_data";
    inserted: number;
    updated: number;
    error?: string;
  };

  const results: UpsertResult[] = [];

  // ---- 6a. Upsert daily rows (Days 1-3) ----
  if (summary.dailyRows.length > 0) {
    // Inject user_id from session (RLS will validate)
    const rowsWithUser = summary.dailyRows.map((r) => ({
      ...r,
      user_id: user.id,
    }));

    const { data, error } = await supabase
      .from("daily_campaign_data")
      .upsert(rowsWithUser as never, {
        onConflict: upsertConflict,
        ignoreDuplicates: false,
      })
      .select("id");

    if (error) {
      console.error("[upload] daily upsert error:", error);
      results.push({
        table: "daily_campaign_data",
        inserted: 0,
        updated: 0,
        error: error.message,
      });
    } else {
      // Note: Supabase upsert doesn't distinguish insert vs update in the response.
      // We report total affected rows; the caller can infer replacements.
      results.push({
        table: "daily_campaign_data",
        inserted: data?.length ?? 0,
        updated: 0, // unknown — see note above
      });
    }
  }

  // ---- 6b. Upsert catchup rows (Day 4) ----
  if (summary.catchupRows.length > 0) {
    const rowsWithUser = summary.catchupRows.map((r) => ({
      ...r,
      user_id: user.id,
    }));

    const { data, error } = await supabase
      .from("catchup_campaign_data")
      .upsert(rowsWithUser as never, {
        onConflict: upsertConflict,
        ignoreDuplicates: false,
      })
      .select("id");

    if (error) {
      console.error("[upload] catchup upsert error:", error);
      results.push({
        table: "catchup_campaign_data",
        inserted: 0,
        updated: 0,
        error: error.message,
      });
    } else {
      results.push({
        table: "catchup_campaign_data",
        inserted: data?.length ?? 0,
        updated: 0,
      });
    }
  }

  // ---- 7. Build response ----
  const dailyResult = results.find((r) => r.table === "daily_campaign_data");
  const catchupResult = results.find((r) => r.table === "catchup_campaign_data");

  const hasErrors = results.some((r) => r.error);
  const totalProcessed =
    (dailyResult?.inserted ?? 0) + (catchupResult?.inserted ?? 0);

  return NextResponse.json(
    {
      success: !hasErrors,
      fileName: summary.fileName,
      sheetName: summary.sheetName,
      totalRows: summary.totalRows,
      daily: {
        parsed: summary.dailyRows.length,
        upserted: dailyResult?.inserted ?? 0,
        error: dailyResult?.error ?? null,
      },
      catchup: {
        parsed: summary.catchupRows.length,
        upserted: catchupResult?.inserted ?? 0,
        error: catchupResult?.error ?? null,
      },
      skipped: summary.skipped,
      rowErrors: summary.errors,
      unmappedHeaders: summary.unmappedHeaders,
      message: hasErrors
        ? `Upload completed with errors. ${totalProcessed} row(s) upserted.`
        : `Upload successful. ${totalProcessed} row(s) upserted.`,
    },
    { status: hasErrors ? 207 : 200 }
  );
}

// ---- GET endpoint: quick health check ----
export async function GET() {
  return NextResponse.json({
    endpoint: "/api/upload",
    method: "POST",
    accepts: ".xlsx, .xls",
    maxSize: `${MAX_FILE_BYTES / 1024 / 1024} MB`,
    authRequired: true,
  });
}
