"use client";

// ============================================================================
//  MasterAnalytics Pro — Upload Form (Client Component)
//  Drag-and-drop .xlsx upload with progress + detailed per-row results.
//  Author: M. Nadeem Akhtar (https://www.facebook.com/itxmasterjee)
// ============================================================================

import { useState, useCallback, useRef } from "react";
import {
  UploadCloud,
  FileSpreadsheet,
  Loader2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  Download,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

// ---------------------------------------------------------------------------
//  Types — mirror the /api/upload response
// ---------------------------------------------------------------------------

interface SkippedRow {
  status: "skipped";
  rowNumber: number;
  reason?: string;
}

interface ErrorRow {
  status: "error";
  rowNumber: number;
  reason?: string;
}

interface UploadResponse {
  success: boolean;
  fileName: string;
  sheetName: string;
  totalRows: number;
  daily: { parsed: number; upserted: number; error: string | null };
  catchup: { parsed: number; upserted: number; error: string | null };
  skipped: SkippedRow[];
  rowErrors: ErrorRow[];
  unmappedHeaders: string[];
  message: string;
}

// ---------------------------------------------------------------------------

const ACCEPT = ".xlsx,.xls";

export function UploadForm() {
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<UploadResponse | null>(null);
  const [progress, setProgress] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  // ---- File selection ----
  const handleFile = useCallback((f: File | null) => {
    if (!f) return;
    const ext = f.name.slice(f.name.lastIndexOf(".")).toLowerCase();
    if (ext !== ".xlsx" && ext !== ".xls") {
      toast.error("Invalid file type", {
        description: `Please upload an .xlsx or .xls file (got ${ext}).`,
      });
      return;
    }
    if (f.size > 10 * 1024 * 1024) {
      toast.error("File too large", {
        description: `Max 10 MB. Your file is ${(f.size / 1024 / 1024).toFixed(2)} MB.`,
      });
      return;
    }
    setFile(f);
    setResult(null);
    setProgress(0);
  }, []);

  const onInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFile(e.target.files?.[0] ?? null);
  };

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragging(false);
      handleFile(e.dataTransfer.files?.[0] ?? null);
    },
    [handleFile]
  );

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(true);
  };

  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
  };

  // ---- Upload ----
  const onUpload = useCallback(async () => {
    if (!file || loading) return;

    setLoading(true);
    setResult(null);
    setProgress(10);

    try {
      const formData = new FormData();
      formData.append("file", file);

      setProgress(30);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      setProgress(80);

      const data: UploadResponse & { error?: string; detail?: string } =
        await res.json();

      setProgress(100);

      if (!res.ok && !data.fileName) {
        // Hard error (no parse happened)
        toast.error("Upload failed", {
          description: data.error || `HTTP ${res.status}`,
        });
        setResult(null);
        return;
      }

      setResult(data);

      if (data.success) {
        toast.success("Upload complete", {
          description: data.message,
        });
      } else {
        toast.warning("Upload completed with issues", {
          description: data.message,
        });
      }
    } catch (err) {
      toast.error("Network error", {
        description: err instanceof Error ? err.message : "Please try again.",
      });
    } finally {
      setLoading(false);
      setTimeout(() => setProgress(0), 1500);
    }
  }, [file, loading]);

  const reset = () => {
    setFile(null);
    setResult(null);
    setProgress(0);
    if (inputRef.current) inputRef.current.value = "";
  };

  // ---- Render ----
  return (
    <div className="space-y-6">
      {/* Dropzone */}
      <div
        onDrop={onDrop}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        className={cn(
          "relative rounded-2xl border-2 border-dashed p-8 text-center transition-colors",
          dragging
            ? "border-blue-500 bg-blue-50"
            : "border-slate-300 bg-white hover:border-slate-400",
          loading && "pointer-events-none opacity-60"
        )}
      >
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT}
          onChange={onInputChange}
          className="hidden"
          disabled={loading}
        />

        {!file ? (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="flex w-full flex-col items-center gap-3"
          >
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-blue-50">
              <UploadCloud className="h-7 w-7 text-blue-600" />
            </span>
            <div>
              <p className="font-semibold text-slate-900">
                Drop your Excel file here, or{" "}
                <span className="text-blue-600 underline">browse</span>
              </p>
              <p className="mt-1 text-sm text-slate-500">
                Supports .xlsx, .xls — max 10 MB
              </p>
            </div>
          </button>
        ) : (
          <div className="flex flex-col items-center gap-3">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-green-50">
              <FileSpreadsheet className="h-7 w-7 text-green-600" />
            </span>
            <div className="text-center">
              <p className="font-medium text-slate-900">{file.name}</p>
              <p className="mt-1 text-xs text-slate-500">
                {(file.size / 1024).toFixed(1)} KB
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => inputRef.current?.click()}
                disabled={loading}
              >
                Change file
              </Button>
              <Button
                size="sm"
                onClick={onUpload}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Uploading…
                  </>
                ) : (
                  <>
                    <UploadCloud className="h-4 w-4" />
                    Upload &amp; Process
                  </>
                )}
              </Button>
            </div>
          </div>
        )}

        {/* Progress bar */}
        {progress > 0 && (
          <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
            <div
              className="h-full bg-gradient-to-r from-blue-600 to-cyan-500 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        )}
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-4">
          {/* Summary card */}
          <div
            className={cn(
              "rounded-2xl border p-6",
              result.success
                ? "border-green-200 bg-green-50"
                : "border-amber-200 bg-amber-50"
            )}
          >
            <div className="flex items-start gap-3">
              {result.success ? (
                <CheckCircle2 className="h-6 w-6 shrink-0 text-green-600" />
              ) : (
                <AlertTriangle className="h-6 w-6 shrink-0 text-amber-600" />
              )}
              <div className="flex-1">
                <h3 className="font-semibold text-slate-900">
                  {result.success ? "Upload successful" : "Upload completed with issues"}
                </h3>
                <p className="mt-1 text-sm text-slate-600">{result.message}</p>

                {/* Quick stats */}
                <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <Stat label="Total rows" value={result.totalRows} />
                  <Stat
                    label="Daily upserted"
                    value={result.daily.upserted}
                    error={!!result.daily.error}
                  />
                  <Stat
                    label="Catch-up upserted"
                    value={result.catchup.upserted}
                    error={!!result.catchup.error}
                  />
                  <Stat
                    label="Skipped / errors"
                    value={
                      result.skipped.length + result.rowErrors.length
                    }
                    warning={
                      result.skipped.length + result.rowErrors.length > 0
                    }
                  />
                </div>

                {/* Table-level errors */}
                {result.daily.error && (
                  <p className="mt-3 text-sm text-red-700">
                    <strong>Daily table error:</strong> {result.daily.error}
                  </p>
                )}
                {result.catchup.error && (
                  <p className="mt-1 text-sm text-red-700">
                    <strong>Catch-up table error:</strong> {result.catchup.error}
                  </p>
                )}

                {/* Unmapped headers (informational) */}
                {result.unmappedHeaders.length > 0 && (
                  <div className="mt-3">
                    <p className="text-xs font-medium text-slate-500">
                      Unmapped columns (ignored):{" "}
                      {result.unmappedHeaders.length}
                    </p>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {result.unmappedHeaders.slice(0, 10).map((h) => (
                        <Badge key={h} variant="outline" className="text-xs">
                          {h}
                        </Badge>
                      ))}
                      {result.unmappedHeaders.length > 10 && (
                        <Badge variant="outline" className="text-xs">
                          +{result.unmappedHeaders.length - 10} more
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4 flex gap-2">
              <Button variant="outline" size="sm" onClick={reset}>
                <RotateCcw className="h-4 w-4" />
                Upload another
              </Button>
              <Button asChild variant="outline" size="sm">
                <a href="/dashboard">
                  <Download className="h-4 w-4" />
                  Go to Dashboard
                </a>
              </Button>
            </div>
          </div>

          {/* Skipped rows table */}
          {result.skipped.length > 0 && (
            <RowTable
              title="Skipped rows"
              icon={<AlertTriangle className="h-4 w-4 text-amber-600" />}
              rows={result.skipped}
              variant="warning"
            />
          )}

          {/* Error rows table */}
          {result.rowErrors.length > 0 && (
            <RowTable
              title="Row errors"
              icon={<XCircle className="h-4 w-4 text-red-600" />}
              rows={result.rowErrors}
              variant="destructive"
            />
          )}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
//  Small sub-components
// ---------------------------------------------------------------------------

function Stat({
  label,
  value,
  error,
  warning,
}: {
  label: string;
  value: number;
  error?: boolean;
  warning?: boolean;
}) {
  return (
    <div className="rounded-lg bg-white/70 p-3">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
        {label}
      </p>
      <p
        className={cn(
          "mt-1 text-2xl font-bold",
          error
            ? "text-red-600"
            : warning
              ? "text-amber-600"
              : "text-slate-900"
        )}
      >
        {value}
      </p>
    </div>
  );
}

function RowTable({
  title,
  icon,
  rows,
  variant,
}: {
  title: string;
  icon: React.ReactNode;
  rows: { rowNumber: number; reason?: string }[];
  variant: "warning" | "destructive";
}) {
  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
      <div className="flex items-center gap-2 border-b border-slate-200 bg-slate-50 px-4 py-2.5">
        {icon}
        <h4 className="text-sm font-semibold text-slate-900">{title}</h4>
        <Badge variant={variant} className="ml-auto">
          {rows.length}
        </Badge>
      </div>
      <div className="max-h-64 overflow-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-slate-50 text-xs text-slate-500">
            <tr>
              <th className="px-4 py-2 text-left font-medium">Excel row</th>
              <th className="px-4 py-2 text-left font-medium">Reason</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((r) => (
              <tr key={r.rowNumber} className="hover:bg-slate-50">
                <td className="px-4 py-2 font-mono text-xs text-slate-600">
                  {r.rowNumber}
                </td>
                <td className="px-4 py-2 text-slate-700">{r.reason ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
