// ============================================================================
//  MasterAnalytics Pro — Upload Page (Server Component)
//  Author: M. Nadeem Akhtar (https://www.facebook.com/itxmasterjee)
// ============================================================================

import Link from "next/link";
import { Activity, ArrowLeft, Info } from "lucide-react";

import { requireUser } from "@/lib/supabase/server";
import { UserMenu } from "@/components/user-menu";
import { UploadForm } from "./upload-form";

export const metadata = { title: "Upload Campaign Data" };

export default async function UploadPage() {
  const user = await requireUser();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/80 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
          <Link href="/dashboard" className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-cyan-500 text-white">
              <Activity className="h-4 w-4" />
            </span>
            <span className="font-bold tracking-tight text-slate-900">
              MasterAnalytics{" "}
              <span className="bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
                Pro
              </span>
            </span>
          </Link>
          <UserMenu email={user.email} />
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
        {/* Breadcrumb */}
        <Link
          href="/dashboard"
          className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-900"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>

        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-900 sm:text-3xl">
            Upload Campaign Data
          </h1>
          <p className="mt-1 text-slate-500">
            Upload your{" "}
            <code className="rounded bg-slate-100 px-1.5 py-0.5 text-xs">
              .xlsx
            </code>{" "}
            daily or catch-up reports. The parser auto-detects the campaign day
            and routes rows to the correct table.
          </p>
        </div>

        {/* Info banner */}
        <div className="mb-6 flex items-start gap-3 rounded-lg border border-blue-200 bg-blue-50 p-4">
          <Info className="mt-0.5 h-5 w-5 shrink-0 text-blue-600" />
          <div className="text-sm text-blue-900">
            <p className="font-semibold">How cumulative uploads work</p>
            <p className="mt-1 text-blue-700">
              Days 1–3 are <strong>cumulative</strong>. Uploading Day 2 for a UC{" "}
              <strong>replaces</strong> its Day 1 row (the Excel contains running
              totals). Day 4 (catch-up) goes to a separate table. Empty cells,
              <code className="mx-1 rounded bg-white px-1">*</code>
              and <code className="mx-1 rounded bg-white px-1">NA</code> are
              treated as <code className="mx-1 rounded bg-white px-1">0</code>.
            </p>
          </div>
        </div>

        <UploadForm />
      </main>
    </div>
  );
}
